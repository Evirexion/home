<?php

/**
 * SQLite database path.
 *
 * IMPORTANT: Keep this path secret. When possible, point it outside the document root.
 */
return __DIR__ . '/.ht.44880642a18e04d8f6c00346286eecfd/.ht.sqlite';
