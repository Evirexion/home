<?php

/**
 * SQLite database path.
 *
 * IMPORTANT: Keep this path secret. When possible, point it outside the document root.
 */
return __DIR__ . '/.ht.a54e8a6e63d4296c7d98fac3e9e5e30e/.ht.sqlite';
